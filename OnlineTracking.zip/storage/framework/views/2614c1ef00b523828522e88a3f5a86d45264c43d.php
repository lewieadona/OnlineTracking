<!-- Start Footer  -->
<footer>
    <!-- Start copyright  -->
    <!-- <div class="footer-copyright">
        <p class="footer-company">All Rights Reserved. &copy; 2020 <a href="#">Online Tracking</a> Design By :
            <a href="https://html.design/">Digits Trading Corp.</a></p>
    </div> -->
    <!-- End copyright  -->

    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

</footer>
<!-- End Footer  -->

<?php /**PATH C:\laragon\www\OnlineTracking\resources\views/footer.blade.php ENDPATH**/ ?>
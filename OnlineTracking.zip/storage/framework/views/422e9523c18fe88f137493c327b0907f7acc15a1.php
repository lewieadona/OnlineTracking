<!-- Start Main Top -->
<div class="main-top">
    <div class="container-fluid">
        <div class="row">

        </div>
    </div>
</div>
<!-- End Main Top -->

<!-- Start Main Top -->
<header class="main-header">
    <!-- Start Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav" style="box-shadow: 5px 1px 5px 1px #6f6f6f;">
        <div class="container">
            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="/">Return Form</a>
            </div>
            <!-- End Header Navigation -->

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="navbar-menu"></div>
            <!-- /.navbar-collapse -->

            <!-- Start Atribute Navigation -->
            <div class="attr-nav"></div>
        </div>
    </nav>
    <!-- End Navigation -->
</header>
<!-- End Main Top --><?php /**PATH C:\Xampp7\htdocs\OnlineTracking\resources\views/header.blade.php ENDPATH**/ ?>
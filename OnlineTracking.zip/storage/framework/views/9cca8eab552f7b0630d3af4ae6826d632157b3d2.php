   
    <script>
        function showCity()
        {
            var provinces = document.getElementById("provinces").value;

            $.ajax
            ({ 
                url: "<?php echo e(URL::to('/province')); ?>",
                type: "POST",
                data: {
                    'provinces': provinces,
                    _token: '<?php echo csrf_token(); ?>'
                    },
                success: function(result)
                {
                    var i;
                    var showData = [];

                    for (i = 0; i < result.length; ++i) {
                        var j = i + 1;
                        showData[i] = "<option value='"+result[i].citymunCode+"'>"+result[i].citymunDesc+"</option>";
                    }
                    $('#selectedcities').find('option').remove();
                    jQuery("#selectedcities").html(showData);               
                }
            });

            $.ajax
            ({ 
                url: "<?php echo e(URL::to('/city')); ?>",
                type: "POST",
                data: {
                    'provinces': provinces,
                    _token: '<?php echo csrf_token(); ?>'
                    },
                success: function(result)
                {
                    var i;
                    var showData = [];

                    for (i = 0; i < result.length; ++i) {
                        var j = i + 1;
                        showData[i] = "<option value='"+result[i].id+"'>"+result[i].brgyDesc+"</option>";
                    }
                    $('#brgytextfield').remove();
                    $('#selectedbrgy').removeAttr('hidden');
                    $('#selectedbrgy').attr("required", true);
                    jQuery("#selectedbrgy").html(showData);              
                }
            });
        }

        function showBrngy()
        {
            var cities = document.getElementById("selectedcities").value;

            $.ajax
            ({ 
                url: "<?php echo e(URL::to('/city')); ?>",
                type: "POST",
                data: {
                    'cities': cities,
                    _token: '<?php echo csrf_token(); ?>'
                    },
                success: function(result)
                {
                    var i;
                    var showData = [];

                    for (i = 0; i < result.length; ++i) {
                        var j = i + 1;
                        showData[i] = "<option value='"+result[i].id+"'>"+result[i].brgyDesc+"</option>";
                    }

                    $('#brgytextfield').remove();
                    $('#selectedbrgy').removeAttr('hidden');
                    $('#selectedbrgy').attr("required", true);
                    jQuery("#selectedbrgy").html(showData);   
                }
            });
        }

        function selectedOther()
        {
            var others = document.getElementById("items_included").value;

            if(others == 1)
            {
                var element = document.getElementById("changeclass");
                element.className = element.className.replace(/\bcol-md-12\b/g, "col-md-6");

                addField = `
                    <label class='mb-0'>Other Items Included</label>
                    <input type="text" class="form-control" name="items_included_others" placeholder="Other Items Included" required> `

                $("#show_other_item").html(addField);
            }
        }

        var numArray = [];
        function OtherProblemDetail() {

            numArray = [];
            var vals = $('#ProblemDetail').val();
            numArray.push(vals);

            numArray.forEach(function(opd) {
                opd.forEach(myFunction);
            });
        }

        function myFunction(item, index) {
            if(item == 26){
                addinputField = `
                    <label class='mb-0'>Other Problem Details</label>
                    <input type="text" class="form-control" name="problem_details_other" placeholder="Other Problem Details" required> `

                $("#show_other_problem").html(addinputField);
            }
        }

        function showStores()
        {
            var channel = document.getElementById("channels").value;
            $.ajax
            ({ 
                url: "<?php echo e(URL::to('/stores')); ?>",
                type: "POST",
                data: {
                    'stores': channel,
                    _token: '<?php echo csrf_token(); ?>'
                    },
                success: function(result)
                {
                    var i;
                    var showData = [];

                    showData[0] = "<option value='' selected disabled>Choose store here...</option>";
                    for (i = 1; i < result.length; ++i) {
                        var j = i + 1;
                        showData[i] = "<option value='"+result[i].store_name+"'>"+result[i].store_name+"</option>";
                    }

                    $('#selectedStores').find('option').remove();
                    jQuery("#selectedStores").html(showData);               
                }
            });
        }
    </script>

    <!-- Initialize the plugin: -->
    <script type="text/javascript">
        $(".chosen-select").chosen({
        no_results_text: "Oops, nothing found!"
        })
    </script>

    <!-- ALL JS FILES -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>

</html><?php /**PATH C:\laragon\www\OnlineTracking\resources\views/script.blade.php ENDPATH**/ ?>
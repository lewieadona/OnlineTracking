<!DOCTYPE html>
<html>
<head>
    <title>Return Request</title>
</head>
<body>
    <h3><?php echo e($details['title']); ?></h3>
    <p>Please check your email for a copy of your request. A representative will reach out to you in a few days to process your concern.</p>
    <p><?php echo e($details['body']); ?> <b><?php echo e($details['reference_no']); ?></b></p>
    <p>Thank you!</p>
</body>
</html><?php /**PATH C:\laragon\www\OnlineTracking\resources\views/email/gmail.blade.php ENDPATH**/ ?>
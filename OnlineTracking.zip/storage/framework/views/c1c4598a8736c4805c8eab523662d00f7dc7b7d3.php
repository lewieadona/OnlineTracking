<?php echo $__env->make('meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

<!-- Start Slider -->
<div class="content bg-cover">
    <div class="search" style="padding: 200px 0;">
        <h1 class="title-homepage"><strong>Track Your Return</strong></h1>
        
        <form class="searchform" method="post" action="<?php echo e(URL::to('/trackingresult')); ?>">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input type="text" placeholder="Enter a valid tracking number here..." name="search">
            <button type="submit"><i class="fa fa-search"></i></button>
        </form>

        <div class="add-pr">
            <a class="btn hvr-hover button-create" href="<?php echo e(URL::to('/createForm')); ?>">Create a Return Request</a>
        </div>

        <?php if(!empty($result['route'])): ?>
            <?php if($result['route'] == 'trackingresult'): ?>
                <!-- Start Wishlist  -->
                <div class="wishlist-box-main">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="table-main table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Reference Number</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody style="background-color:white;">
                                        <?php if(count($result['search']) > 0): ?>
                                            <?php $__currentLoopData = $result['search']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="name-pr">
                                                    <a href="#">
                                                        <?php echo e($search->return_reference_no); ?>

                                                    </a>
                                                </td>
                                                <td class="quantity-box">
                                                    <p><?php echo e($search->warranty_status); ?></p>
                                                </td>
                                                <td class="quantity-box">
                                                    <p><?php echo e($search->created_at); ?></p>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr>
                                                <td class="quantity-box" colspan="3">
                                                    <p align="center">No result found!</p>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Wishlist -->
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<!-- End Slider -->

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

<?php echo $__env->make('script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
<?php /**PATH C:\laragon\www\OnlineTracking\resources\views/index.blade.php ENDPATH**/ ?>
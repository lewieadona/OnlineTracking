@include('meta')
@include('header')  

<!-- Start Slider -->
<div class="content bg-cover">
    <div class="search" style="padding: 200px 0;">
        <h1 class="title-homepage"><strong>Track Your Return</strong></h1>
        
        <form class="searchform" method="post" action="{{ URL::to('/trackingresult')}}">
            <input type="hidden" name="_token" value="{{ csrf_token() }}">
            <input type="text" placeholder="Enter a valid tracking number here..." name="search">
            <button type="submit"><i class="fa fa-search"></i></button>
        </form>

        <div class="add-pr">
            <a class="btn hvr-hover button-create" href="{{ URL::to('/createForm')}}">Create a Return Request</a>
        </div>

        @if(!empty($result['route']))
            @if($result['route'] == 'trackingresult')
                <!-- Start Wishlist  -->
                <div class="wishlist-box-main">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="table-main table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Reference Number</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody style="background-color:white;">
                                        @if(count($result['search']) > 0)
                                            @foreach($result['search'] as $search)
                                            <tr>
                                                <td class="name-pr">
                                                    <a href="#">
                                                        {{$search->return_reference_no}}
                                                    </a>
                                                </td>
                                                <td class="quantity-box">
                                                    <p>{{ $search->warranty_status }}</p>
                                                </td>
                                                <td class="quantity-box">
                                                    <p>{{$search->created_at}}</p>
                                                </td>
                                            </tr>
                                            @endforeach
                                        @else
                                            <tr>
                                                <td class="quantity-box" colspan="3">
                                                    <p align="center">No result found!</p>
                                                </td>
                                            </tr>
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Wishlist -->
            @endif
        @endif
    </div>
</div>
<!-- End Slider -->

@include('footer')  

@include('script')  

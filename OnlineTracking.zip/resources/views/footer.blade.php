<!-- Start Footer  -->
<footer>
    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>
</footer>
<!-- End Footer  -->


<!DOCTYPE html>
<html>
<head>

    <title>Return Request</title>
</head>
<body>
    <style>
    * {
        box-sizing: border-box;
    }

    .column {
        float: left;
        width: 50%;
        padding: 10px;
        height: 300px;
    }

    .row:after {
        content: "";
        display: table;
        clear: both;
    }

    .text-muted {
        color: #6c757d!important;
    }

    .mb-1, .my-1 {
        margin-bottom: .25rem!important;
    }
    </style>

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body p-0">
                        <div class="row">
                            <div class="col">
                                <h3>{{ $details['title'] }}</h3>
                                <p>A representative will reach out to you in a few days to process your concern. Please keep your email and phone lines open so that we can contact you.</p>
                                <p>{{ $details['body'] }} <b>{{ $details['alldetails']->return_reference_no }}</b></p>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col">
                                <p class="font-weight-bold mb-4"></p>
                                <p class="mb-1"><span class="text-muted">Full Name: </span>{{ $details['alldetails']->customer_last_name }}, {{ $details['alldetails']->customer_first_name }}</p>
                                <p class="mb-1"><span class="text-muted">Address: </span>{{ $details['alldetails']->address }}</p>
                                <p class="mb-1"><span class="text-muted">Contact Number: </span>{{ $details['alldetails']->contact_no }}</p>
                                <p class="mb-1"><span class="text-muted">Email Address: </span>{{ $details['alldetails']->email_address }}</p>
                                <p class="mb-1"><span class="text-muted">Store: </span>{{ $details['alldetails']->store }}</p>
                                <p class="mb-1"><span class="text-muted">Order Number: </span>{{ $details['alldetails']->order_no }}</p>
                                <p class="mb-1"><span class="text-muted">Purchase Amount: </span>{{ $details['alldetails']->cost }}</p>
                                <p class="mb-1"><span class="text-muted">Purchase Location: </span>{{ $details['alldetails']->purchase_location }}</p>
                                <p class="mb-1"><span class="text-muted">Purchase Date: </span>{{ $details['alldetails']->purchase_date }}</p>
                                <p class="mb-1"><span class="text-muted">Mode of Payment: </span>{{ $details['alldetails']->mode_of_payment }}</p>
                                @if($details['alldetails']->purchase_location !== "RETAIL STORE")
                                    <p class="mb-1"><span class="text-muted">Bank Name: </span>{{ $details['alldetails']->bank_name }}</p>
                                    <p class="mb-1"><span class="text-muted">Bank Account Number: </span>{{ $details['alldetails']->bank_account_no }}</p>
                                    <p class="mb-1"><span class="text-muted">Bank Account Name: </span>{{ $details['alldetails']->bank_account_name }}</p>
                                @endif
                             
                                <p class="mb-1"><span class="text-muted">Mode of Return: </span>{{ $details['alldetails']->mode_of_return }}</p>
                                @if($details['alldetails']->purchase_location == "RETAIL STORE")
                                <p class="mb-1"><span class="text-muted">Branch: </span>{{ $details['alldetails']->branch }}</p>
                                @endif

                                @if($details['alldetails']->mode_of_return == "STORE DROP-OFF") 
                                    <p class="mb-1"><span class="text-muted">Store Drop-Off: </span>{{ $details['alldetails']->store_dropoff }}</p>
                                    <p class="mb-1"><span class="text-muted">Branch Drop-Off: </span>{{ $details['alldetails']->branch_dropoff }}</p>
                                @endif

                            
                            </div>

                            <div class="col">
                                <p class="font-weight-bold mb-4"></p>
                                <p class="mb-1"><span class="text-muted">Item Description: </span>{{ $details['alldetails']->item_description }}</p>
                                <p class="mb-1"><span class="text-muted">Serial Number: </span>{{ $details['alldetails']->serial_number }}</p>
                                <p class="mb-1"><span class="text-muted">Problem Details: </span>{{ $details['alldetails']->problem_details }} @if(!empty($details['alldetails']->problem_details_other)), {{$details['alldetails']->problem_details_other}} @endif</p>
                                <p class="mb-1"><span class="text-muted">Items Included: </span>{{ $details['alldetails']->items_included }} @if(!empty($details['alldetails']->items_included_others)), {{$details['alldetails']->items_included_others}} @endif</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>